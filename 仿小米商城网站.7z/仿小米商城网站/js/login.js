$(document).ready(function(){
    users();
    changeStatus();
    login();
    loginClosed();
});
function users(){}
users.prototype.user = [
    {user:'sa',password:'x1234567'}
];

function changeStatus(){
    var LoginOrSignup = document.querySelector('#LoginOrSignup');
    LoginOrSignup.onclick = function(){
        document.querySelector('#helper').innerHTML=null;
        document.querySelector('#Username').value=null;
        document.querySelector('#Password').value=null;
        if(this.innerHTML == 'Signup'){
            this.innerHTML = 'Login';
            document.querySelector('.form > h2').innerHTML = 'Sign up';
            document.querySelector('input[type="submit"]').value = 'Sign up';
            signUp();
        }else{
            this.innerHTML = 'Signup';
            document.querySelector('input[type="submit"]').value = 'Login';
            document.querySelector('.form > h2').innerHTML = 'Sign in';
            login();
        }
    }
}

function login(){
    document.querySelector('input[type="submit"]').onclick = _ => {
        var user = document.querySelector('#Username').value;
        var password = document.querySelector('#Password').value;
        document.querySelector('#Password').value = '';
        var uids = users.prototype.user;
        var helper = document.querySelector('#helper');
        var success = false;
        for(var i = 0;i<uids.length;++i){
            if(user === uids[i].user){
                if(password === uids[i].password){
                    success = true;
                    break;
                }
            }
        }
        if(success===true){
            helper.innerHTML='登录成功 2秒后跳转回首页';
            document.querySelector('#index-login-button').innerHTML = '欢迎你，' + user + '！';
            document.querySelector('#index-signup-logout').innerHTML = '注销';
            var jump = setTimeout(_=>{
                helper.innerHTML='';
                document.querySelector('.loginclosed').click();
                document.querySelector('#index-signup-logout').onclick = function(){
                    document.querySelector('#Username').value = '';
                    document.querySelector('#index-login-button').innerHTML = '登录';
                    this.innerHTML = '注册';
                    this.onclick = function(){
                        document.querySelector('.login').style.display = 'flex';
                        document.querySelector('.index').style.display = 'none';
                    }
                }
            },2000);
        }else{
            helper.innerHTML='用户名不存在或密码错误！';
        }
    }
}
function signUp(){
    document.querySelector('input[type="submit"]').onclick = _ => {
        var user = document.querySelector('#Username').value;
        var password = document.querySelector('#Password').value;
        document.querySelector('#Password').value = '';
        var uids = users.prototype.user;
        var helper = document.querySelector('#helper');
        // 正则验证
        var reguid = /^(\w+@\w+(\.\w+)+)|([1]\d{10})$/;
        var regpwd = /^([^0-9]+)\w{5,}$/;
        var matchuid = user.match(reguid);
        var matchpwd = password.match(regpwd);
        if(matchuid==null||matchuid==false){
            helper.innerHTML = '请验证账号是否为邮箱或中国大陆手机号！';
            return;
        }
        if(matchpwd==null||matchpwd==false){
            helper.innerHTML = '密码为非数字开头且不少于6位';
            return;
        }
        helper.innerHTML = '注册成功';
        
        uids[uids.length] = {user: user,password:password}
    }
}

function loginClosed(){
    var closed = document.querySelector('.loginclosed');
    closed.onclick = _=>{
        document.querySelector('.login').style.display = 'none';
        document.querySelector('.index').style.display = 'block';
    }
}