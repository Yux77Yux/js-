$(document).ready(function(){
    //小米logo回到首页页面
    document.querySelector('#logo').onclick = function(){
        document.querySelector('.index-content').style.display = 'block';
        document.querySelector('.footer').style.display = 'block';
        document.querySelector('.detailed').style.display = 'none';
        document.querySelector('.shopping').style.display = 'none';
    }
    //地区切换
    gps('.gps');

    //用户登录注册显示
    userLoginOrSignup();

    //购物车显示
    document.querySelector('.shop').onclick = function(){
        document.querySelector('.index-content').style.display = 'none';
        document.querySelector('.footer').style.display = 'block';
        document.querySelector('.detailed').style.display = 'none';
        document.querySelector('.shopping').style.display = 'block';
    }

    //搜索框的下拉列表
    showList('#search-text');

    //轮播
    var delay = 5000;
    var timer = null;
    timer = setInterval(imgChange,delay);
    //轮播波点按钮滑动切换图
    carouselMouseover();
    //往左以及往右滑动轮播
    prevOrnextClick();

    //秒杀倒计时
    seckillTimmer();
    //秒杀栏轮播
    seckillCarousel();

    //广告关闭
    closeAd();

    //详细页面
    detailedshowing();
});
//切换地区 切换首页背景
function gps(option){
    $(option).find('ol').find('li').find('a').click(function(){
        $(this).parent().siblings().removeClass('region');
        $(this).parent().addClass('region');
        var region = document.querySelector('#region');
        region.innerText = document.querySelector('.region').innerText;
        var color;
        switch(region.innerText)
        {
            case '中国大陆':color = '#f6f6f6';break;
            case '中国香港':color = '#abcccc';break;
            case '中国澳门':color = '#89cccc';break;
            case '中国台湾':color = '#cdcccc';break;
            case '全球':color = '#adcccc';break;
        }
        document.querySelector('body').style.backgroundColor = color;
    });
}

//用户登录注册显示
function userLoginOrSignup(){
    var loginOrSignup = document.querySelectorAll('.loginOrSignup');
    for(var i=0;i<loginOrSignup.length;++i){
        loginOrSignup[i].onclick = _=>{
            document.querySelector('.login').style.display = 'flex';
            document.querySelector('.index').style.display = 'none';
        }
    }
}

//当搜索框获得焦点时显示搜索框下的的推荐选项
function showList(option){
    $(option).on('focus',function(){
        $('.search-list').show();
    });
    $(option).on('blur',function(){
        $('.search-list').hide();
    });
}

//轮播
function imgChange(){
    var Carouseled = document.querySelector('.Carouseled');
    var ul = Carouseled.parentNode.parentNode.parentNode;
    var index = 0;
    for(var i = 0;i<ul.children.length;++i){
        if(ul.children[i] === Carouseled.parentNode.parentNode){
            index = i;
            break;
        }
    }
    Carouseled.setAttribute('class','blured');
    index = index+1===ul.children.length?0:index+1;
    ul.children[index].children[0].children[0].setAttribute('class','blured Carouseled');
    dotChange(index);
}
function dotChange(option){
    var index = option;
    var focused = document.querySelector('.focused');
    var paginations = document.querySelectorAll('.pagination');
    focused.setAttribute('class','pagination');
    paginations[index].setAttribute('class','pagination focused');
}
//轮播波点按钮滑动切换图
function carouselMouseover(){
    var paginations = document.querySelectorAll('.pagination');
    for(var i = 0;i<paginations.length;++i){
        paginations[i].onmouseover = function(){
            //将选中前的轮播图隐藏
            var Carouseled = document.querySelector('.Carouseled');
            var ul = Carouseled.parentNode.parentNode.parentNode;
            Carouseled.setAttribute('class','blured');
            //找到滑动的对象
            for(var i = 0;i<paginations.length;++i){
                if(paginations[i] === this){
                    dotChange(i);
                    ul.children[i].children[0].children[0].setAttribute('class','blured Carouseled');
                    break;
                }
            }
        }
    }
}
//往左以及往右滑动轮播
function prevOrnextClick(){
    prevClick();
    nextClick();
}
function prevClick(){
    var prev = document.querySelector('.button-prev');
    prev.onclick = function(){
        //将点击前的轮播图隐藏
        var Carouseled = document.querySelector('.Carouseled');
        var ul = Carouseled.parentNode.parentNode.parentNode;
        Carouseled.setAttribute('class','blured');

        var paginations = document.querySelectorAll('.pagination');
        var focused = document.querySelector('.focused');
        var index;
        for(var i = 0;i<paginations.length;++i){
            if(paginations[i] === focused){
                index = i;
                break;
            }
        }
        index = index-1<0?paginations.length-1:index-1;
        ul.children[index].children[0].children[0].setAttribute('class','blured Carouseled');
        dotChange(index);
    }
}
function nextClick(){
    var next = document.querySelector('.button-next');
    next.onclick = function(){
        //将点击前的轮播图隐藏
        var Carouseled = document.querySelector('.Carouseled');
        var ul = Carouseled.parentNode.parentNode.parentNode;
        Carouseled.setAttribute('class','blured');

        var paginations = document.querySelectorAll('.pagination');
        var focused = document.querySelector('.focused');
        var index;
        for(var i = 0;i<paginations.length;++i){
            if(paginations[i] === focused){
                index = i;
                break;
            }
        }
        index = index+1>4?0:index+1;
        ul.children[index].children[0].children[0].setAttribute('class','blured Carouseled');
        dotChange(index);
    }
}

//秒杀倒计时
function seckillTimmer(){
    //显示当前的时间与期限之差
    var hours = document.querySelector('.timmer-hour');
    var minutes = document.querySelector('.timmer-minute');
    var seconds = document.querySelector('.timmer-second');
    hours.innerHTML = 23 - new Date().getHours();
    minutes.innerHTML = 59 - new Date().getMinutes();
    seconds.innerHTML = 59 - new Date().getSeconds();
    hours.innerHTML = parseInt(hours.innerHTML)<10?'0'+parseInt(hours.innerHTML):parseInt(hours.innerHTML);
    minutes.innerHTML = parseInt(minutes.innerHTML)<10?'0'+parseInt(minutes.innerHTML):parseInt(minutes.innerHTML);
    seconds.innerHTML = parseInt(seconds.innerHTML)<10?'0'+parseInt(seconds.innerHTML):parseInt(seconds.innerHTML);

    var timmerSecond = null;
    var second = 1000;
    timmerSecond = setInterval(secondInterval,second);
}
function secondInterval(){
    var seconds = document.querySelector('.timmer-second');
    var now = 59 - new Date().getSeconds();
    if(now>=59)changeMinute();
    seconds.innerHTML = now<10?'0' + now:now;
}
function changeMinute(){
    var minutes = document.querySelector('.timmer-minute');
    var now = 59 - new Date().getMinutes();
    if(now>=59)changeHour();
    minutes.innerHTML = parseInt(minutes.innerHTML) - 1<10?'0' + (parseInt(minutes.innerHTML) - 1):parseInt(minutes.innerHTML) - 1;
    if(minutes.innerHTML === '59')changeHour();
}
function changeHour(){
    var hours = document.querySelector('.timmer-hour');
    hours.innerHTML = parseInt(hours.innerHTML) - 1<10?'0' + (parseInt(hours.innerHTML) - 1):parseInt(hours.innerHTML) - 1;
}
//秒杀栏轮播
function seckillCarousel(){
    //往左以及往右滑动轮播
    document.querySelector('.button-left').addEventListener('click',_=>leftClick(document.querySelectorAll('.seckill-imglist')));
    document.querySelector('.button-right').addEventListener('click',_=>rightClick(document.querySelectorAll('.seckill-imglist')));
}
function leftClick(options){
    var showimglist = document.querySelector('.showimglist');
    var imglist = options;
    showimglist.setAttribute('class','seckill-imglist');
    var index = 0;
    for(var i = 0;i<imglist.length;++i){
        if(imglist[i] === showimglist){
            index = i;
            break;
        }
    }
    index = index-1<0?imglist.length-1:index-1;
    imglist[index].setAttribute('class','seckill-imglist showimglist');
}
function rightClick(options){
    var showimglist = document.querySelector('.showimglist');
    var imglist = options;
    showimglist.setAttribute('class','seckill-imglist');
    var index = 0;
    for(var i = 0;i<imglist.length;++i){
        if(imglist[i] === showimglist){
            index = i;
            break;
        }
    }
    index = index+1>=imglist.length?0:index+1;
    imglist[index].setAttribute('class','seckill-imglist showimglist');
}

//广告
function closeAd(){
    //点击关闭广告
    document.querySelector('.ad-righttop').onclick=_=>rtClick();
    //页面滚动移到末尾隐藏
    window.addEventListener('scroll',_=>handleScroll(),true);
}
function rtClick(){
    document.querySelector('.ad').style.display = 'none';
}
function handleScroll(){
     //变量scrollTop是滚动条滚动时，距离顶部的距离
     let scrollTop = document.documentElement.scrollTop||document.body.scrollTop;
     //变量windowHeight是可视区的高度
     let windowHeight = document.documentElement.clientHeight || document.body.clientHeight;
     //变量scrollHeight是滚动条的总高度
     let scrollHeight = document.documentElement.scrollHeight||document.body.scrollHeight;
     //滚动条到底部的条件
     if(Math.round(scrollTop + windowHeight) >= scrollHeight){
        document.querySelector('.ad').style.transform = 'scaleY(0)';
     }else{
        document.querySelector('.ad').style.transform = 'scaleY(1)';
     }
}


//详细页面显示
function detailedshowing(){
    //导航栏点击商品
    var navBarlis = document.querySelectorAll('.nav-bar-list > .wrap > ul > li');
    for(var i=0;i<navBarlis.length;++i){
        navBarlis[i].children[0].onclick = function(){
            document.querySelector('.detailed').style.display = 'block';
            document.querySelector('.index-content').style.display = 'none';
            document.querySelector('.shopping').style.display = 'none';
            ids(
                this.querySelector('.nav-img img').getAttribute('src'),
                this.querySelectorAll('p')[0].innerHTML,
                parseInt(this.querySelectorAll('p')[1].innerHTML)
                );
        }
    }
    //限时处点击商品
    var seckillImgs = document.querySelectorAll('.seckill-imglist');
    for(var i=0;i<seckillImgs.length;++i){
        var li =seckillImgs[i].querySelectorAll('li');
        for(var j = 0;j<li.length;++j){
            li[j].onclick = function(){
                document.querySelector('.detailed').style.display = 'block';
                document.querySelector('.index-content').style.display = 'none';
                ids(
                    this.querySelector('img').getAttribute('src'),
                    this.querySelector('.seckill-title').innerHTML,
                    parseInt(this.querySelector('.num').innerHTML),
                    this.querySelector('.desc-complete').innerHTML
                );
            }
        }
    }
}

function ids(imgsrc,title,priceNum,descText = ''){
    var smallImg = document.querySelector('#detailed-img');
    var bigImg = document.querySelector('#bigImg');
    var desc = document.querySelector('.detailed-desc');
    var price = document.querySelector('#price-num');
    var title1 = document.querySelector('.detailed-left-h2');
    var title2 = document.querySelector('.detailed-right-h2');
    title1.innerHTML = title;
    title2.innerHTML = title;
    smallImg.setAttribute('src',imgsrc);
    bigImg.setAttribute('src',imgsrc);
    desc.innerHTML = descText;
    price.innerHTML = priceNum;
}