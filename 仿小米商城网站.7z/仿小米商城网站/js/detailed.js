$(document).ready(function(){
    //放大
    maskShow();
    //评论
    commentSubmit();
    //加入购物车
    addShopping();
});

//放大
function maskShow(){
    $('#smallImg').on({
        mousemove:
        function(event){
            var bigBox = document.querySelector('#bigBox');
            bigBox.style.display = 'block';

            var mask = document.querySelector('#mask');
            mask.style.display = 'block';

            var smallBox = document.querySelector('#smallImg');

            var event = event || window.event;
            var pageX = event.pageX || event.clientX + document.documentElement.scrollLeft;
            var pageY = event.pageY || event.clientY + document.documentElement.scrollTop;
            var boxX = pageX - smallBox.offsetLeft;
            var boxY = pageY - smallBox.offsetTop;
            var maskX = boxX - mask.offsetWidth / 2;
            var maskY = boxY - mask.offsetHeight / 2;
            var bigImg = document.querySelector('#bigImg');
            var bigImgToMove = bigImg.offsetWidth - bigBox.offsetWidth;
            var maskToMove = smallBox.offsetWidth - mask.offsetWidth;
            var rate = bigImgToMove / maskToMove;
            bigImg.style.left = -rate * maskX + 'px';
            bigImg.style.top = -rate * maskY + 'px';

            mask.style.left = maskX + 150 + 'px';
            mask.style.top = maskY - 192 + 'px';
        },
        mouseout:
        function(){
            document.querySelector('#mask').style.display = 'none';
            document.querySelector('#bigBox').style.display = 'none';
        }
    });
}

//评论
function commentSubmit(){
    document.querySelector('#comment').onclick = _=>{
        var user = document.querySelector('#Username').value;
        user = user==''?'用户':user;
        var comments = document.querySelector('.comments');
        var text = user + ':' + document.querySelector('#comment-input').value;
        var newComment = document.createElement('p');
        var newClass = document.createAttribute('class');
        newClass.value = 'comment';
        newComment.setAttributeNode(newClass);
        var content = document.createTextNode(text);
        newComment.appendChild(content);
        comments.appendChild(newComment);
    }
}

//加入购物车
function addShopping(){
    document.querySelector('#selected').onclick = function(){
        var name = document.querySelector('.detailed-left-h2').innerHTML;
        var src = document.querySelector('#detailed-img').getAttribute('src');
        var price = parseInt(document.querySelector('#price-num').innerHTML);
        /*if(this.value == '√'){
            this.value = '加入购物车';
            var goods = document.querySelectorAll('.googs-name');
            for(var i=0;i<goods.length;++i){
                if(goods[i].innerHTML == name){
                    var parent = goods[i].parentNode;
                    parent.querySelector('.goods-action').click();
                }
            }
        }else{
            this.value = '√';*/
            var goodsBody = document.querySelector('.goods-body');

            var goods = document.createElement('div');
            var goodsClass = document.createAttribute('class');
            goodsClass.value = 'goods';
            goods.setAttributeNode(goodsClass);
            
            //div.goods-check
            var goodsCheck = document.createElement('div');
            var goodsCheckClass = document.createAttribute('class');
            goodsCheckClass.value = 'goods-check';
            goodsCheck.setAttributeNode(goodsCheckClass);

            var goodsIcorn =  document.createElement('input');
            var goodsIcornClass = document.createAttribute('class');
            var goodsIcornType = document.createAttribute('type');
            goodsIcornType.value = 'checkbox';
            goodsIcornClass.value = 'goods-icorn';
            goodsIcorn.setAttributeNode(goodsIcornType);
            goodsIcorn.setAttributeNode(goodsIcornClass);
            goodsCheck.appendChild(goodsIcorn);

            goods.appendChild(goodsCheck);


            //div.goods-img
            var goodsImg = document.createElement('div');
            var goodsImgClass = document.createAttribute('class');
            goodsImgClass.value = 'goods-img';
            goodsImg.setAttributeNode(goodsImgClass);
            var goodsColImg = document.createElement('img');
            var goodsColImgClass = document.createAttribute('class');
            var goodsColImgSrc = document.createAttribute('src');
            goodsColImgClass.value = 'goods-img';
            goodsColImgSrc.value = src;
            goodsColImg.setAttributeNode(goodsColImgClass);
            goodsColImg.setAttributeNode(goodsColImgSrc);
            goodsImg.appendChild(goodsColImg);
            goods.appendChild(goodsImg);


            //div.goods-name
            var goodsName = document.createElement('div');
            var goodsNameClass = document.createAttribute('class');
            goodsNameClass.value = 'goods-name';
            goodsName.setAttributeNode(goodsNameClass);
            var goodsNameText = document.createTextNode(name);
            goodsName.appendChild(goodsNameText);
            goods.appendChild(goodsName);


            //div.goods-price
            var goodsPrice = document.createElement('div');
            var goodsPriceClass = document.createAttribute('class');
            goodsPriceClass.value = 'goods-price';
            goodsPrice.setAttributeNode(goodsPriceClass);
            var goodsPriceText = document.createTextNode(price+'元');
            goodsPrice.appendChild(goodsPriceText);
            goods.appendChild(goodsPrice);


            //div.goods-num
            var goodsNum = document.createElement('div');
            var goodsNumClass = document.createAttribute('class');
            goodsNumClass.value = 'goods-num';
            goodsNum.setAttributeNode(goodsNumClass);

            var goodsNumSub = document.createElement('button');
            var goodsNumSubClass = document.createAttribute('class');
            goodsNumSubClass.value = 'goods-num-sub';
            goodsNumSub.setAttributeNode(goodsNumSubClass);
            var goodsNumSubText = document.createTextNode('-');
            goodsNumSub.appendChild(goodsNumSubText);
            goodsNum.appendChild(goodsNumSub);

            var goodsNumNum = document.createElement('span');
            var goodsNumNumClass = document.createAttribute('class');
            goodsNumNumClass.value = 'goods-num-num';
            goodsNumNum.setAttributeNode(goodsNumNumClass);
            var goodsNumNumText = document.createTextNode('1');
            goodsNumNum.appendChild(goodsNumNumText);
            goodsNum.appendChild(goodsNumNum);

            var goodsNumAdd = document.createElement('button');
            var goodsNumAddClass = document.createAttribute('class');
            goodsNumAddClass.value = 'goods-num-add';
            goodsNumAdd.setAttributeNode(goodsNumAddClass);
            var goodsNumAddText = document.createTextNode('+');
            goodsNumAdd.appendChild(goodsNumAddText);
            goodsNum.appendChild(goodsNumAdd);

            goods.appendChild(goodsNum);


            //div.goods-total
            var goodsTotal = document.createElement('div');
            var goodsTotalClass = document.createAttribute('class');
            goodsTotalClass.value = 'goods-total';
            goodsTotal.setAttributeNode(goodsTotalClass);
            var goodsTotalText = document.createTextNode(price + '元');
            goodsTotal.appendChild(goodsTotalText);
            goods.appendChild(goodsTotal);


            //button.goods-action
            var goodsAction = document.createElement('div');
            var goodsActionClass = document.createAttribute('class');
            goodsActionClass.value = 'goods-action';
            goodsAction.setAttributeNode(goodsActionClass);
            var goodsActionText = document.createTextNode('×');
            goodsAction.appendChild(goodsActionText);
            goods.appendChild(goodsAction);

            goodsBody.appendChild(goods);
            //激活新节点的点击事件
            deleteGood();
            littletotal();
            chooseNums();

            setTimeout(function(){
                document.querySelector('.detailed').style.display = 'none';
                document.querySelector('.shopping').style.display = 'block';
            },1500);
            alert('已加入购物车');
    }
}