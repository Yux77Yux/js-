$(document).ready(function(){
    //删除商品
    deleteGood();
    //小计
    littletotal();
    //结算
    document.querySelector('#total-clear').onclick = _=>clearGoods();
    //全选或全不选
    document.querySelector('.col-icorn').onclick = function(){
        var selected = this.checked;
        var selects = document.querySelectorAll('.goods-icorn');
        for(var i=0;i<selects.length;++i){
            selects[i].checked = selected;
        }
        ergodic();
    }
    //选择件数
    chooseNums();
});

//删除商品
function deleteGood(){
    var actions = document.querySelectorAll('.goods-action');
    for(var i=0;i<actions.length;++i){
        actions[i].onclick = function(){
            var parent = this.parentNode;
            parent.parentNode.removeChild(parent);
            ergodic();
            document.querySelector('#total-clear').click();
        }
    }
}
//小计
function littletotal(){
    var subs = document.querySelectorAll('.goods-num-sub');
    var adds = document.querySelectorAll('.goods-num-add');
    for(var i=0;i<subs.length;++i){
        subs[i].onclick = function(){
            var parent = this.parentNode;
            var num = parent.querySelector('.goods-num-num');
            console.log(num.innerHTML);
            var valueNum = parseInt(num.innerHTML)-1;
            valueNum = valueNum<0?0:valueNum;
            num.innerHTML = valueNum;
            allTotal(parent.parentNode);
        }
    }
    for(var i=0;i<adds.length;++i){
        adds[i].onclick = function(){
            var parent = this.parentNode;
            var num = parent.querySelector('.goods-num-num');
            var valueNum = parseInt(num.innerHTML)+1;
            num.innerHTML = valueNum;
            allTotal(parent.parentNode);
        }
    }
}
function allTotal(option){
    var oneTotal = option.querySelector('.goods-total');
    var price = parseInt(option.querySelector('.goods-price').innerHTML);
    var nums = option.querySelector('.goods-num-num').innerHTML;
    oneTotal.innerHTML = price * nums +'元';
}
function clearGoods(){
    var totals = document.querySelectorAll('.goods-total');
    var prices = 0;
    for(var i=0;i<totals.length;++i){
        var parent = totals[i].parentNode;
        var selected = parent.querySelector('.goods-icorn').checked;
    console.log(selected);

        if(selected === true){
            prices += parseInt(totals[i].innerHTML);
        }
    }
    document.querySelector('#price-total').innerHTML = prices;
    var money = prompt('请输入余额','');
    if(parseInt(money) == 0){
        alert('零元购成功！');
    }else if(parseInt(money)<prices){
        alert('余额不足');
    }else{
        alert('结算成功');
    }
}

//选择件数
function chooseNums(){
    var selects = document.querySelectorAll('.goods-icorn');
    for(var i=0;i<selects.length;++i){
        selects[i].addEventListener('change',function(){
            var pieces = document.querySelector('#goods-total');
            if(this.checked){
                pieces.innerHTML = parseInt(pieces.innerHTML)+1;
            }else{
                pieces.innerHTML = parseInt(pieces.innerHTML)-1;
            }
        });
    }
}

//遍历是否选中
function ergodic(){
    var pieces = document.querySelector('#goods-total');
    var selects = document.querySelectorAll('.goods-icorn');
    var chooses = 0;
    for(var i=0;i<selects.length;++i){
        if(selects[i].checked)chooses++;
    }
    pieces.innerHTML = chooses;
}